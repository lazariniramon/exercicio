<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'todolist');
define('DB_USER', 'root');
define('DB_PASS', '');

?>