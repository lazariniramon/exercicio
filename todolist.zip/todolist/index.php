<?php 

function __autoload($class_name){
	//echo $class_name;
	require_once 'class/' . $class_name . '.php';
}

$Tarefa = new Tarefa();
// echo "<pre>";
// print_r($Tarefa);

// foreach($Tarefa->findAll() as $Tarefa){
// print_r($Tarefa);
// }
// die;

?>
<html>
<head>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body>
	<div class="container">
		
		<?php 
		if (isset($_POST['cadastrar'])) {
			$nometarefa = $_POST['nometarefa'];
			if ($nometarefa != '') {
				$Tarefa->setTarefa($nometarefa);
				$Tarefa->setFeito(0);
				if ($Tarefa->insert()) {
					echo "<script> alert('Inserido com sucesso'); </script>";
				}
			}else{
				echo "<script> alert('Por favor, escreva o nome da tarefa!'); </script>";
			}
		}

		if (isset($_GET['acao']) && $_GET['acao'] == 'deletar') {
			$id = (int)$_GET['id'];
			if ($Tarefa->delete($id)) {
				$redirect = "index.php";
				header("location:$redirect");
			}
		}
		if (isset($_GET['acao']) && $_GET['acao'] == 'atualizar') {
			$id = (int)$_GET['id'];
			$checked = (int)$_GET['checked'];
			if ($Tarefa->update($id, $checked)) {
				$redirect = "index.php";
				header("location:$redirect");
			}
		}
		?>
		<form method="post" action="">

			<div id="myDIV" class="header">

				<h2 style="margin:5px">To Do List</h2>
				<div class="input-prepend">
					<input type="text" id="myInput" placeholder="Title..." name="nometarefa">
				</div>
				<input type="submit" name="cadastrar"  class="addBtn"/>
			</div>
		</form>
		<table class="table table-striped" align="center">
			<tbody>
				<?php foreach($Tarefa->findAll() as $Tarefa){ ?>
				<tr>
					<td  class="col-md-1">

						<?php

						$feito = $Tarefa['feito']==0 ?  "" : "<span class='glyphicon glyphicon-ok'aria-hidden='true'></span>"; 
						echo $feito;
						?>
					</td>
					<td  class="col-md-10"><!-- <input type="checkbox" name="feito" <?php echo $Tarefa['feito']==1 ?  ' checked' : ''; ?>> -->
						<?php 
						$checked = $Tarefa['feito']==1 ?  0 : 1;
						echo "<a href='index.php?acao=atualizar&id=". $Tarefa['id']."&checked=".$checked."' >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$Tarefa['tarefa']."</a>"; ?>

					</td>
					<!-- <td  class="col-md-10" class="checked"><?php echo $Tarefa['tarefa']; ?></td> -->
					<td  class="col-md-1">
						<?php 
						echo "<a href='index.php?acao=deletar&id=". $Tarefa['id']."' onClick='return confirm(\"Deseja realmente deletar?\")'><span class='glyphicon glyphicon-trash'aria-hidden='true'></span></a>"; ?>
					</td>
				</tr>
				<?php } ?>
			</tbody>
		</table>



		<!-- <div>
			<ul id="myUL">
				<?php foreach($Tarefa->findAll() as $Tarefa){ ?>
				<li <?php echo $Tarefa['feito']==1 ?  'class="checked"' : ''; ?>><?php echo $Tarefa['tarefa']; ?><span class="close" onclick=""  >×</span></li>
				<?php } ?>
			</ul>
		</div> -->


	</div>
</body>
<script src="jquery/jquery-3.1.1.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</html>

